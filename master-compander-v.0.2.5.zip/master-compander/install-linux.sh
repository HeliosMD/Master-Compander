./compile.sh
sudo cp rms /usr/bin/rms
sudo cp peak /usr/bin/peak
sudo cp wav_header /usr/bin/wav_header
sudo cp compander_1 /usr/bin/compander_1
sudo cp sin-compander /usr/bin/sin-compander
sudo cp bulk-compander /usr/bin/bulk-compander
sudo cp master-compander.sh /usr/bin/master-compander
sudo cp master-compander.sh /usr/bin/master-compander.sh
